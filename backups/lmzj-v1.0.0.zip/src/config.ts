export default {
  isMock: true,
  baseUrl: '',
};
